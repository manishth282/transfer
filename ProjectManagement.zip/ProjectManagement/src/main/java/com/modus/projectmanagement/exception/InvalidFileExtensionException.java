package com.modus.projectmanagement.exception;

public class InvalidFileExtensionException extends RuntimeException{

    public InvalidFileExtensionException(String message){
        super(message);
    }
}
